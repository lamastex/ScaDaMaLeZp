==========================================
Seattle Temperature Recordings Data Set
==========================================


This data set was obtained from https://w2.weather.gov/climate/index.php?wfo=sew.  The source of the data is:
National Weather Service
The National Weather Service data is not subject to copyright protection.


=========================================
Data Set Information
=========================================

This is a history weather recordings data set which contains all the high and low temperatures in Seattle, WA occurring between 01/01/2015 and 09/30/2018.

Attribute Information:
date: The date of the temperature recording.
temp: The daily maximum or minimum temperature in Fahrenheit.
